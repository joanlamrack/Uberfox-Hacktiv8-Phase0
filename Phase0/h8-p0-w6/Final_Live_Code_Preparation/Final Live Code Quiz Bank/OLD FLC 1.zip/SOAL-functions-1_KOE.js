//KOE
//Number Processing
//
// RULES
// - Wajib Pseudocode
// - Tidak boleh menggunakan Function bawaan Math apapun.
// - Jika mean dalam bentuk desimal, bulatkan kebawah.
//
// Lihat test case.

function numberProcessing(numberArr) {

}

console.log(numberProcessing([1, 3, 5, 1, 2, 8, 10, 0, 3]));
// "Min: 0, Max: 10, Mean: 3, Odds: 1-3-5-1-3, Evens: 2-8-10-0"
