
function findMax(numberArr) {

}

function findMin(numberArr) {

}

function findMean(numberArr) {

}


function findOdds(numberArr) {

}

function findEvens(numberArr) {

}

function numberProcessing(numberArr) {
  
}

console.log(numberProcessing([1, 3, 5, 1, 2, 8, 10, 0, 3]));
// "Min: 0, Max: 10, Mean: 3, Odds: 1-3-5-1-3, Evens: 2-8-10-0"
