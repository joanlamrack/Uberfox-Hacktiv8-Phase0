/*
Hacktive Final Live Coding 3

Pair Programming

Sebuah function bernama arrangePairs yang akan menerima satu parameter berupa
arrray, yg berisi nama-nama murid dikelas.
function akan mengembalikan sebuah array baru yg merupakan kelompok-kelompok
pembagian tersebut.

output :
['Yani dan Joni', 'Doni dan Roni']
['James dan Jake', 'Jade dan Instruktur']
['Tori dan Nori', 'Sori dan Wori', 'Mori dan Instruktur']
['Rudi dan Instruktur']
[]
*/

function arrangePairs(studentsArr) {
// Waktu sudah habis bro

}

console.log(arrangePairs(['Yani', 'Joni', 'Doni', 'Roni']));
console.log(arrangePairs(['James', 'Jake', 'Jade']));
console.log(arrangePairs(['Toni', 'Nori', 'Sori', 'Wori', 'Mori']));
console.log(arrangePairs(['Rudi']));
console.log(arrangePairs([]));
