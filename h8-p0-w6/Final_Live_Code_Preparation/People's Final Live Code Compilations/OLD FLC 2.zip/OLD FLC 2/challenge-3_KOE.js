//Buat kelompok
// KOE
// RULES: WAJIB PSEUDOCODE

function arrangePairs(studentArr){
  
}

console.log(arrangePairs(['Diky', 'Bambang', 'Handoko'])); //[ 'Diky dan Bambang', 'Handoko dan Instruksur' ]
console.log(arrangePairs(['Adhy', 'Akbar', 'Haidar', 'Juvenita'])); //[ 'Adhy dan Akbar', 'Haidar dan Juvenita' ]
console.log(arrangePairs(['Adhy'])); //[ 'Adhy dan Instruksur' ]
console.log(arrangePairs([])); //[]
