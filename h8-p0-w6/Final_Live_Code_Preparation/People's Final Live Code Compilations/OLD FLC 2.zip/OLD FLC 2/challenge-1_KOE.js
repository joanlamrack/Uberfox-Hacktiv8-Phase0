// Counting Fox Ears

// hint: Each fox has two ears.
// 
// RULES
// - No loop, Recursive only
// - Forbidden to use * math operation
// - PSEUDOCODE is required.

function foxEars(foxs){
  
}

console.log(foxEars(3)); // 6
console.log(foxEars(4)); // 8
console.log(foxEars(6)); // 12
console.log(foxEars(0)); // 0
